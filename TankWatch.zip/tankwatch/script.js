var KEY='tankwatch-v1', WARDS=['East Hamlet','Colony','School','Main Bazaar'];
function fresh(){return{t:7*60,sel:0,sound:false,
 tanks:[
  {n:'Main Panchayat Tank',cap:120,lvl:35,pump:'Idle',base:6.3,inf:14,h:[]},
  {n:'North Hamlet Sump',cap:60,lvl:68,pump:'Idle',base:4.5,inf:12,h:[]},
  {n:'School Overhead Tank',cap:40,lvl:52,pump:'Idle',base:3.6,inf:10,h:[]},
  {n:'Farm Borewell',cap:80,lvl:81,pump:'Idle',base:2.2,inf:9,h:[]}],
 sched:[],dist:{'East Hamlet':60,'Colony':45,'School':30,'Main Bazaar':60},
 week:[118,124,131,127,140,135],today:0,alerts:[]}}
var S;
try{S=JSON.parse(localStorage.getItem(KEY));}catch(e){S=null}
if(!S||!S.tanks)S=fresh();
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
var $=function(i){return document.getElementById(i)};
function fac(m){var h=m/60%24;return(h>=6&&h<9)||(h>=17&&h<20)?1.6:(h>=22||h<5)?.3:1}
function status(l){return l<20?['Critical low','var(--crit)']:l<40?['Warning','var(--warn)']:l>95?['Overflow risk','var(--over)']:['Normal','var(--ok)']}
function hm(m){m=Math.floor(m)%1440;return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0')}
var ctx=null;
function tone(freq,duration,type,volume,delay){
  if(!S.sound)return;
  try{
    ctx=ctx||new(window.AudioContext||window.webkitAudioContext)();
    if(ctx.state==='suspended')ctx.resume();
    var o=ctx.createOscillator(),g=ctx.createGain(),start=ctx.currentTime+(delay||0);
    o.type=type||'sine';o.frequency.setValueAtTime(freq,start);
    g.gain.setValueAtTime(0,start);g.gain.linearRampToValueAtTime(volume||.07,start+.025);
    g.gain.exponentialRampToValueAtTime(.001,start+(duration||.18));
    o.connect(g);g.connect(ctx.destination);o.start(start);o.stop(start+(duration||.18)+.02);
  }catch(e){}
}
function beep(){tone(880,.22,'sine',.10);tone(660,.28,'sine',.07,.12)}
function successSound(){tone(523,.13,'sine',.07);tone(659,.13,'sine',.07,.12);tone(784,.2,'sine',.08,.24)}
function warningSound(){tone(740,.16,'triangle',.09);tone(520,.22,'triangle',.09,.2)}
function clickSound(){tone(620,.07,'sine',.035)}
function avg(a){return a.length?a.reduce(function(x,y){return x+y},0)/a.length:0}
function hours(t){var a=avg(t.h);
 if(a<-0.05)return{txt:'Estimated empty in',v:(t.lvl/-a).toFixed(1)+' hours',c:t.lvl/-a<4?'var(--crit)':'var(--ink)'};
 if(a>0.05)return{txt:t.lvl>=100?'Tank is full':'Estimated full in',v:t.lvl>=100?'':((100-t.lvl)/a).toFixed(1)+' hours',c:'var(--ok)'};
 return{txt:'Level steady',v:'',c:'var(--ink)'}}
function tick(){
 var dt=.25,prev=S.tanks.map(function(t){return status(t.lvl)[0]});
 S.t+=15;if(S.t>=1440){S.t-=1440;S.week.push(Math.round(S.today));S.week=S.week.slice(-6);S.today=0;S.dist={'East Hamlet':0,'Colony':0,'School':0,'Main Bazaar':0}}
 S.tanks.forEach(function(t,i){
  var use=t.base*fac(S.t)*(0.9+Math.random()*.2),net=-use;
  S.today+=use*dt*t.cap/100;
  if(t.pump==='Running'){net+=t.inf;if(t.lvl>=100)t.pump='Idle'}
  t.lvl=Math.max(0,Math.min(100,t.lvl+net*dt));
  t.h.push(net);if(t.h.length>8)t.h.shift();
  var st=status(t.lvl)[0];
  if(st!==prev[i]&&(st==='Critical low'||st==='Overflow risk')){S.alerts.unshift(hm(S.t)+' – '+t.n+': '+st+' ('+Math.round(t.lvl)+'%)');S.alerts=S.alerts.slice(0,4);beep()}
 });
 S.sched.forEach(function(s){if(!s.done&&S.t>=s.at&&S.t<s.at+15){s.done=true;S.dist[s.ward]=(S.dist[s.ward]||0)+s.dur}});
 save();render()}
var tabsKey='';
function render(){
 var T=S.tanks[S.sel],st=status(T.lvl),H=hours(T),L=Math.round(T.lvl);
 $('clk').textContent=hm(S.t);
 $('tabs').innerHTML=S.tanks.map(function(t,i){var s=status(t.lvl);return '<button class="tab" data-i="'+i+'" aria-pressed="'+(i===S.sel)+'"><b>'+t.n+'</b>'+Math.round(t.lvl)+'% · '+s[0]+'<div class="bar"><i style="width:'+t.lvl+'%;background:'+s[1]+'"></i></div></button>'}).join('');
 $('tname').textContent=T.n;$('pct').textContent=L+'%';
 var p=$('state');p.textContent=st[0];p.style.background=st[1];
 $('vol').textContent=(T.cap*T.lvl/100).toFixed(1)+' m³ of '+T.cap+' m³ · safe buffer '+Math.max(0,(T.cap*(T.lvl-20)/100)).toFixed(1)+' m³';
 var y=150-140*T.lvl/100;
 $('wg').style.transform='translateY('+(y-10)+'px)';
 $('wp').setAttribute('d','M-60 10 q15 -9 30 0 t30 0 t30 0 t30 0 t30 0 t30 0 t30 0 V30 H-60Z');
 $('hours').innerHTML=H.txt+' <b style="color:'+H.c+'">'+H.v+'</b>';
 var ps=$('pstate');ps.textContent=T.pump;ps.style.background=T.pump==='Running'?'var(--ok)':T.pump==='Tripped'?'var(--crit)':'var(--mute)';
 $('alerts').innerHTML=S.alerts.length?'<div class="card alert"><h2>Alerts</h2><ul>'+S.alerts.map(function(a){return '<li>'+a+'</li>'}).join('')+'</ul></div>':'';
 $('sched').innerHTML=S.sched.slice(-4).map(function(s){return '<li>'+s.ward+' · '+hm(s.at)+' · '+s.dur+' min '+(s.done?'(done)':'(waiting)')+'</li>'}).join('')||'<li class="sub">No supply scheduled yet.</li>';
 $('dist').innerHTML=WARDS.map(function(w){return '<tr><td>'+w+'</td><td>'+(S.dist[w]||0)+' min</td></tr>'}).join('');
 updChart()}
var chart;
function updChart(){
 var labels=['6d','5d','4d','3d','2d','Yesterday','Today'],data=S.week.concat([Math.round(S.today)]);
 if(typeof Chart==='undefined')return;
 if(!chart){chart=new Chart($('ch'),{type:'bar',data:{labels:labels,datasets:[{label:'m³',data:data,backgroundColor:'#1f8fb5',borderRadius:5}]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:850,easing:'easeOutQuart'},plugins:{legend:{display:false}}}})}
 else{chart.data.datasets[0].data=data;chart.update('active')}}
$('tabs').addEventListener('click',function(e){var b=e.target.closest('.tab');if(b){S.sel=+b.dataset.i;render()}});
$('pon').onclick=function(){var t=S.tanks[S.sel];if(t.lvl<100&&t.pump!=='Running'){t.pump='Running';successSound()}save();render()};
$('poff').onclick=function(){S.tanks[S.sel].pump='Idle';clickSound();save();render()};
$('ptrip').onclick=function(){S.tanks[S.sel].pump='Tripped';S.alerts.unshift(hm(S.t)+' – '+S.tanks[S.sel].n+': pump tripped');S.alerts=S.alerts.slice(0,4);warningSound();save();render()};
$('sch').onclick=function(){var v=$('at').value.split(':');S.sched.push({ward:$('ward').value,at:(+v[0])*60+(+v[1]),dur:+$('dur').value,done:false});successSound();save();render()};
$('snd').onclick=function(){S.sound=!S.sound;$('snd').textContent=S.sound?'♫ Sound on':'♪ Sound off';if(S.sound)successSound();save()};
function net(){var o=!navigator.onLine,b=$('net');b.textContent=o?'Cached data (offline)':'Live';b.className='badge'+(o?' off':'')}
addEventListener('online',net);addEventListener('offline',net);net();
$('snd').textContent=S.sound?'♫ Sound on':'♪ Sound off';
render();setInterval(tick,1500);
